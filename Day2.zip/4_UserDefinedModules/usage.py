# import math
# print(math)

# import words
# print(words)
# words.fetch_words()

from words import fetch_words
fetch_words()
