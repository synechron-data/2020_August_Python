# def greetings(msg, name):
#     return msg + ", " + name


# print(greetings("Good Morning", "Manish"))
# print(greetings("Good Morning", "Abhijeet"))
# print(greetings("Good Morning", "Ramakant"))


# def converter(toUnit, factor, offset, inp):
#     return (str((offset+inp)*factor) + " " + toUnit)


# print(converter('km', 1.6, 0, 10))
# print(converter('km', 1.6, 0, 100))
# print(converter('km', 1.6, 0, 240))
# print(converter('km', 1.6, 0, 890))

# print(converter('INR', 71, 0, 10))
# print(converter('INR', 71, 0, 100))
# print(converter('INR', 71, 0, 240))
# print(converter('INR', 71, 0, 890))

# ----------------------------------------------------------------- Currying
def greetings(msg):
    def greet(name):
        return msg + ", " + name
    return greet


# mGreeet = greetings("Good Morning")

# print(mGreeet("Manish"))
# print(mGreeet("Abhijeet"))
# print(mGreeet("Ramakant"))

# aGreeet = greetings("Good Afternoon")

# print(aGreeet("Manish"))
# print(aGreeet("Abhijeet"))
# print(aGreeet("Ramakant"))


def get_converter(toUnit, factor, offset):
    def converter(inp):
        return (str((offset+inp)*factor) + " " + toUnit)
    return converter


milesToKm = get_converter('km', 1.6, 0)
# print(milesToKm)

print(milesToKm(10))
print(milesToKm(100))
print(milesToKm(240))
print(milesToKm(890))


usdToInr = get_converter('INR', 71, 0)

print(usdToInr(10))
print(usdToInr(100))
print(usdToInr(240))
print(usdToInr(890))
