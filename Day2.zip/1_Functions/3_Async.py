import random
import threading


def set_interval(fn, sec):
    def fn_wrapper():
        set_interval(fn, sec)
        fn()
    t = threading.Timer(sec, fn_wrapper)
    t.start()
    return t


def getString():
    nameList = ["Python", "JavaScript", "Java", "DotNet", "Scala"]
    return random.choice(nameList)


# s = getString()
# print(s)
# s = getString()
# print(s)
# s = getString()
# print(s)
# s = getString()
# print(s)

# def display():
#     s = getString()
#     print(s)

# set_interval(display, 2)

def pushString(cb):
    def push():
        s = random.choice(nameList)
        cb(s)

    nameList = ["Python", "JavaScript", "Java", "DotNet", "Scala"]
    set_interval(push, 2)


pushString(lambda s: print(s))
print("--------- Last Line ---------")
