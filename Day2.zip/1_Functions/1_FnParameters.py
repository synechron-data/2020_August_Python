# non-default argument should not follow default argument
# def add(x=0, y=0):
#     return x+y


# print(add(2, 3))
# print(add(2))
# print(add())


# --------------------------------------------  non-keyworded. variable-length argument list
# def addAll(*numbers):
#     print(type(numbers))
#     sum = 0
#     for n in numbers:
#         sum += n
#     return sum


# print(addAll())
# print(addAll(1))
# print(addAll(1, 2))
# print(addAll(1, 2, 3, 4, 5))
# print(addAll(1, 2, 3, 4, 5, 6, 7, 8, 9))

# list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
# print(addAll(*list))        # Spread a List

# ----------------------

# def average(*numbers):
#     sum = 0
#     for n in numbers:
#         sum += n
#     if len(numbers):
#         return sum / len(numbers)
#     else:
#         return sum


# print(average())
# print(average(1))
# print(average(1, 2))
# print(average(1, 2, 3, 4, 5))
# print(average(1, 2, 3, 4, 5, 6, 7, 8, 9))

# list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
# print(average(*list))

# -----------------------------------------------
# import copy

# data1 = [[1, 2, 3, 4, 5], 20, 30, 40, 50]
# # data2 = data1

# # SHALLOW COPY
# # data2 = data1[::]
# # data2 = *data1            # Error: can't use starred expression here
# # data2 = [*data1]          # List Spread

# # data2 = copy.copy(data1)

# # DEEP COPY
# data2 = copy.deepcopy(data1)

# print("data1: ", id(data1))
# print("data2: ", id(data2))

# data2[0][0] = 1000
# data2[1] = 2000

# print("data1: ", data1)
# print("data2: ", data2)

# --------------------------------------------  Destructuring List

# data1 = [10, 20, 30, 40, 50]

# # a = data1[0]
# # b = data1[1]

# # a, b, _, _, _ = data1
# # a, b, *rest = data1
# # a, _, _, _, b = data1
# a, *rest, b = data1

# print("a: ", a)
# print("b: ", b)
# print("rest: ", rest)

# ------------------------------------------------------ keyworded, variable-length argument list

# def printData(id, name="Abhijeet", city="Mumbai"):
#     print("Id: ", id)
#     print("Name: ", name)
#     print("City: ", city)


# printData(1)
# printData(1, "Manish", "Pune")
# printData(id=1, name="Manish", city="Pune")

# printData(1, "Pune")
# printData(1, city="Pune")

def printData(**kwargs):
    print(kwargs)
    print(type(kwargs))


# printData(1, "Manish", "Pune")          #TypeError: printData() takes 0 positional arguments but 3 were given
# printData(id=1, name="Manish", city="Pune")

myEmployee = {"id": 2, "name": "Abhijeet", "city": "Mumbai"}
# print(myEmployee)
# print(type(myEmployee))

# printData(myEmployee) # TypeError: printData() takes 0 positional arguments but 1 was given
# printData(**myEmployee)

print(myEmployee)
print(*myEmployee)