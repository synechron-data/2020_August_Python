# count = 0


# def next():
#     global count
#     count = count + 1
#     return count


# print(next())
# print(next())
# count = "abc"
# print(next())
# print(next())

# ----------------------------------------
# A closure—unlike a plain function—allows the function to access those captured 
# variables through the closure’s copies of their values or references, even when the 
# function is invoked outside their scope.

def next():
    count = 0

    def next():
        nonlocal count
        count = count + 1
        return count
    return next

next = next()

print(next())
print(next())
count = "abc"
print(next())
print(next())
