# def addAll(*numbers):
#     sum = 0
#     for n in numbers:
#         sum += n
#     return sum

# r = addAll(1, 2, 3, 4, 5, 6, 7, 8, 9)
# print(r)
# print("Test")

# ------------------------------------------ Fn passed as argument to another Fn
# Dev 1


# def addAll(numbers, callback):
#     # HTTP Call to some other server
#     sum = 0
#     for n in numbers:
#         sum += n
#     callback(sum)


# def subtractAll(numbers, fn):
#     # HTTP Call to some other server
#     sum = 0
#     for n in numbers:
#         sum += n
#     fn(sum)

# # Dev 2


# def printResult(result):
#     print("Result is: ", result)


# addAll([1, 2, 3, 4, 5, 6, 7, 8, 9], printResult)
# subtractAll([1, 2, 3, 4, 5, 6, 7, 8, 9], printResult)
# print("Test")

# addAll([1, 2, 3, 4, 5, 6, 7, 8, 9], lambda result: print("Result is: ", result))

# -----------------------------------------------
# numArr = [1, 2, 3, 4, 5]

# # resultArr = []
# # for item in numArr:
# #     n = item * 10
# #     resultArr.append(n)


# # def processItem(item):
# #     return item * 10


# # resultArr = []
# # for item in numArr:
# #     resultArr.append(processItem(item))

# # resultArr = map(processItem, numArr)
# resultArr = map(lambda item: item*10, numArr)
# print(list(resultArr))

# resultArr1 = map(lambda item: item*5, numArr)
# print(list(resultArr1))

# resultArr2 = map(lambda item: item*2, numArr)
# print(list(resultArr2))

# ------------------------------------------------------------ Find all numbers divisible by 2
numArr = [1, 2, 3, 4, 5, 6, 7, 8, 9]

# r = []
# for item in numArr:
#     if item % 2 == 0:
#         r.append(item)

def myFilter(fn, list):
    r = []
    for item in list:
        if fn(item):
            r.append(item)
    return r

# r = filter(lambda item: item % 2 == 0, numArr)
r = myFilter(lambda item: item % 2 == 0, numArr)

print(list(r))
