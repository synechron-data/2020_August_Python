import pandas as pd

# data = {
#     'apples': [3, 2, 0, 1],
#     'oranges': [0, 3, 7, 2]
# }

# # purchases = pd.DataFrame(data)
# purchases = pd.DataFrame(
#     data, index=["Manish", "Abhijeet", "Ramakant", "Subodh"])

# # print(purchases)
# # print(purchases.loc['Abhijeet'])
# # print(purchases.describe())

# # purchases.to_csv("purchases.csv")
# purchases.to_json("purchases.json")


# -------------------------------------------------- Reading from CSV File
movies_df = pd.read_csv("IMDB-Movie-Data.csv", index_col="Title")
# print(movies_df)
# print(movies_df.head(2))
# print(movies_df.tail(2))
# print(movies_df.info())
print(movies_df.shape)




