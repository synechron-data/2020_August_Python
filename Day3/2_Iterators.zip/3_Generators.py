# def idGeneratorFn():
#     yield 1
#     yield 2
#     yield 3

# for i in idGeneratorFn():
#     print(i)

# # print(idGeneratorFn())

# # x = idGeneratorFn()
# # print(next(x))
# # print(next(x))
# # print(next(x))

# ----------------------------------------------


# def fib(n):
#     a, b = 0, 1

#     result = []
#     while a < n:
#         result.append(a)
#         a, b = b, a+b

#     return result

def fib(n):
    a, b = 0, 1

    while a < n:
        yield a
        a, b = b, a+b

# print(fib(15))
for r in fib(15):
    print(r)