# print("List Iteration")
# l = ["Hello", "to", "everyone"]
# for i in l:
#     print(i)

# print("String Iteration")
# s = "Hello World"
# for i in s:
#     print(i)

# print("Number Iteration")   
# n = 101010  
# for i in n:         # TypeError: 'int' object is not iterable
#     print(i)

message = "Hello"

msgIterator = iter(message)
# print(msgIterator)

print(next(msgIterator))
print(next(msgIterator))
print(next(msgIterator))
print(next(msgIterator))
print(next(msgIterator))
print(next(msgIterator))