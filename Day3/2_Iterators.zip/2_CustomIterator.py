# class MyRange:
#     def __init__(self, limit):
#         self._limit = limit

#     def __iter__(self):
#         self._x = 1
#         return self

#     def __next__(self):
#         x = self._x

#         if(x > self._limit):
#             raise StopIteration

#         self._x = x+1
#         return x

# obj = MyRange(10)

# for i in obj:
#     print(i)

# obj1 = range(10)

# for i in obj1:
#     print(i)

# ---------------------------------------------------- Queue


class Queue:
    def __init__(self):
        self._children = []

    def push(self, data):
        self._children.append(data)

    def __iter__(self):
        return iter(self._children)
        
    # def __iter__(self):
    #     for i in self._children:
    #         yield i


numbersQ = Queue()

numbersQ.push(10)
numbersQ.push(20)
numbersQ.push(30)

for n in numbersQ:
    print(n)
