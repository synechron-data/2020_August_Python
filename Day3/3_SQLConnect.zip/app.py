import pyodbc

conn = pyodbc.connect('Driver={SQL Server};'
                      'Server=.\\SQLEXPRESS;'
                      'Database=Northwind;'
                      'Trusted_Connection=yes;')

# print(conn)

cursor = conn.cursor()
rows = cursor.execute('SELECT * FROM Northwind.dbo.Customers')

# print(list(rows))
for row in rows:
    print(row)
