# ---------------------------------------- List
# data = [1, 2, 3, 4, 5, "Pune"]
# print(data)
# print(type(data))

# print(data[0])
# print(data[1:4])

# print(id(data))
# # data = [1,2]
# data[0] = "Test"
# print(id(data))

# ---------------------------------------- Tuple
# data = (1, 2, 3, 4, 5, "Pune")
# print(data)
# print(type(data))

# print(data[0])
# print(data[1:4])

# # print(id(data))
# # data = [1,2]
# # data[0] = "Test"
# # print(id(data))

# for a in data:
#     print(a)
#     print("Inside Loop")

# print("Check")


# # ---------------------------------------- Set
# data = {1, 2, 3, 4, 5, "Pune", 1, 2, 3, 4, 5, "Pune"}
# print(data)
# print(type(data))

# for a in data:
#     print(a)

# ---------------------------------------- Dict
# data = {
#     "Manish": "12345",
#     "Abhijeet": "234567",
#     "Ramakant": 3,
#     "Test": True
# }
# print(data)
# print(type(data))

# for a in data:
#     print(a)

# -------------------------------------------- Range
# xRange = range(0, 10)
# print(xRange)
# print(type(xRange))

# # for a in xRange:
# #     print(a)

# # data = list(range(5, 10))
# # data = list(range(6))

# data = tuple(range(0, 10))


# print(data)
# print(type(data))

# ---------------------------------------- Input

# numList = []

# n = int(input("Enter number of items: "))

# for i in range(0, n):
#     inp = int(input())
#     numList.append(inp)

# for i in numList:
#     print(i, end=" ")

# print(numList)
# print(numList + [45, 67])
# print(numList * 3)

# print(10 in numList)
# print(10 not in numList)

# print(numList)

# print(numList[1])
# print(numList[1:3])

numList = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# print(numList[20])
# print(numList[20:25])
# print(numList[0:20:2])
