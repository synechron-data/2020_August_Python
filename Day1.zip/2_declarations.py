# a
# print(a)

# a = "Synechron"
# print(a)
# print(type(a))

# a = 10
# print(a)
# print(type(a))

# a = 10.5
# print(a)
# print(type(a))

# a, b, c = 10, 20.5, "ABC"
# a, b, c = 10, 20.5 # Error: not enough values to unpack
# a = b = c = 10

# print(a)
# print(type(a))

# print(b)
# print(type(b))

# print(c)
# print(type(c))

# --------------------------------------

# a = 10
# print(a)
# print(type(a))

# del a   # Error: name 'a' is not defined
# print(a)
# print(type(a))

# --------------------------------------

# x = "Synechron"
# y = "Synechron"

# print(x)
# print(y)

# print(type(x))
# print(type(y))

# print(id(x))
# print(id(y))
# print(x is y)

# x = "Manish"

# print(id(x))
# print(id(y))
# print(x is y)

x = 10
print(x)
print(type(x))
print(id(x))

x = 20
print(x)
print(type(x))
print(id(x))

x = 10
print(x)
print(type(x))
print(id(x))

y = 10
print(y)
print(type(y))
print(id(y))