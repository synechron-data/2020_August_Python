import sys
# print("Hello {}. Welcome to {}".format(sys.argv[1], sys.argv[2]))
# print(sys.maxsize)   #largest integer a variable can take

# print(sys.path)
print(sys.version)
