# fileRead = open("python.png", "rb")
# fileWrite = open("python-copy.png", "wb")

# while True:
#     byte = fileRead.read(1)
#     if not byte:
#         break
#     fileWrite.write(byte)

# fileRead.close()
# fileWrite.close()

# -----------------------------------------

# with open("python.png", "rb") as fileRead, open("python-copy1.png", "wb") as fileWrite:
#     while True:
#         byte = fileRead.read(1)
#         if not byte:
#             break
#         fileWrite.write(byte)

# print("File Copied...")

# -----------------------------------------
import shutil
shutil.copy("python.png", "python-copy2.png")
print("File Copied...")